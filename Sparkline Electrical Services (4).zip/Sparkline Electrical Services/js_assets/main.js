/* ==========================================================================
   Sparkline Electrical Services — main.js
   Part 3: Enhancing Functionality and SEO

   Sections
   0.  Configuration and data
   1.  Small helpers (DOM building, formatting)
   2.  Site-wide enhancements (current nav link, scroll reveal, share button)
   3.  Count-up animation (About page)
   4.  FAQ accordion (Services page)
   5.  Recent projects: render, search, filter, sort (Services page)
   6.  Lightbox gallery (Services page)
   7.  Form validation engine
   8.  Enquiry form: validation, simulated AJAX submit, cost + availability response
   9.  Contact form: validation and compiled email (mailto:)
   10. Interactive Leaflet map (Contact page)
   11. Start-up

   Security note: user input is only ever written to the page with textContent
   (never innerHTML), so typed text cannot inject HTML or scripts.
   ========================================================================== */

(function () {
    'use strict';

    /* ======================================================================
       0. Configuration and data
       ====================================================================== */

    // The address that compiled contact-form emails are sent to.
    const RECIPIENT_EMAIL = 'info@sparklineelectrical.co.za';

    // true  = demo mode: the enquiry "server" is simulated with a short delay.
    // false = real AJAX: the form is POSTed with fetch() to FORM_ENDPOINT
    //         (for example Netlify Forms once the site is deployed on Netlify).
    const SIMULATE_SERVER = true;
    const FORM_ENDPOINT = '/';

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Branch locations shown on the contact page map.
    const LOCATIONS = [
        {
            id: 'bellville',
            name: 'Main Office – Bellville',
            address: '12 Voortrekker Road, Bellville, 7530',
            phone: '021 555 0134',
            tel: '+27215550134',
            lat: -33.9019,
            lng: 18.6287
        },
        {
            id: 'claremont',
            name: 'Southern Suburbs Depot – Claremont',
            address: '4 Main Road, Claremont, 7708',
            phone: '021 555 0178',
            tel: '+27215550178',
            lat: -33.9855,
            lng: 18.4655
        }
    ];

    // Project data for the "Recent Projects" gallery (rendered dynamically).
    const PROJECTS = [
        {
            id: 'db-board-upgrade',
            title: 'Distribution Board Upgrade',
            category: 'commercial',
            categoryLabel: 'Commercial',
            date: '2026-09-12',
            image: 'db-board-upgrade',
            alt: 'Newly installed distribution board with labelled circuit breakers in a retail unit',
            description: 'Replaced an overloaded distribution board in a Bellville retail unit and fitted new circuit breakers with earth leakage protection.'
        },
        {
            id: 'full-house-rewire',
            title: 'Full House Rewire',
            category: 'residential',
            categoryLabel: 'Residential',
            date: '2026-08-20',
            image: 'full-house-rewire',
            alt: 'Electrician pulling new cabling through the ceiling of a three-bedroom home',
            description: 'Complete rewire of a 1970s three-bedroom home in Claremont, including new plug points, lighting circuits and a fresh Certificate of Compliance.'
        },
        {
            id: 'fault-tracing',
            title: 'Tripping Circuit Fault',
            category: 'maintenance',
            categoryLabel: 'Maintenance',
            date: '2026-08-02',
            image: 'fault-tracing',
            alt: 'Electrician testing a circuit with a multimeter at a distribution board',
            description: 'Traced and repaired an intermittent tripping fault caused by a damaged geyser circuit, restoring safe hot water the same day.'
        },
        {
            id: 'office-led-lighting',
            title: 'Office LED Lighting',
            category: 'commercial',
            categoryLabel: 'Commercial',
            date: '2026-07-15',
            image: 'office-led-lighting',
            alt: 'Open-plan office with newly fitted LED panel lights',
            description: 'Replaced old fluorescent fittings with energy-saving LED panels across a small open-plan office, cutting the monthly lighting bill.'
        },
        {
            id: 'kitchen-circuits',
            title: 'Kitchen Circuits',
            category: 'residential',
            categoryLabel: 'Residential',
            date: '2026-06-30',
            image: 'kitchen-circuits',
            alt: 'Renovated kitchen with new wall plug points above the counter',
            description: 'Installed dedicated circuits and extra plug points for a renovated kitchen, including provision for an oven and dishwasher.'
        },
        {
            id: 'coc-inspection',
            title: 'Compliance Inspection',
            category: 'maintenance',
            categoryLabel: 'Maintenance',
            date: '2026-06-10',
            image: 'coc-inspection',
            alt: 'Electrician completing a Certificate of Compliance inspection checklist',
            description: 'Full electrical inspection ahead of a property sale, with minor defects corrected and a Certificate of Compliance issued.'
        }
    ];

    // Cost guide shown after the enquiry form is submitted.
    const PRICING = {
        'residential-wiring': {
            label: 'Residential Wiring',
            estimate: 'R1 200 – R3 500 for a typical small job such as extra plug points, lighting circuits or minor repairs.',
            note: 'Full or partial rewires are quoted after a free on-site inspection.'
        },
        'commercial-installation': {
            label: 'Commercial Installation',
            estimate: 'R4 500 – R18 000 for small offices, shops and workshops.',
            note: 'We begin with a free site assessment so your quote is accurate.'
        },
        'fault-finding': {
            label: 'Fault Finding / Maintenance',
            estimate: 'R650 call-out fee (includes the first hour), then R550 per hour plus materials.',
            note: 'Most faults are traced and repaired in a single visit.'
        },
        'other': {
            label: 'Other',
            estimate: 'We will assess your request and send you a custom quote.',
            note: 'Please include as much detail as possible in your message.'
        }
    };


    /* ======================================================================
       1. Small helpers
       ====================================================================== */

    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    /**
     * Create an element without using innerHTML.
     * attrs: { class, text, dataset: {...}, any-other-attribute }
     */
    function el(tag, attrs = {}, children = []) {
        const node = document.createElement(tag);
        Object.entries(attrs).forEach(([key, value]) => {
            if (value === false || value === null || value === undefined) return;
            if (key === 'class') node.className = value;
            else if (key === 'text') node.textContent = value;
            else if (key === 'dataset') Object.assign(node.dataset, value);
            else node.setAttribute(key, value === true ? '' : value);
        });
        children.forEach(child => node.append(child));
        return node;
    }

    function startOfToday() {
        const d = new Date();
        d.setHours(0, 0, 0, 0);
        return d;
    }

    function debounce(fn, delay) {
        let timer;
        return (...args) => {
            clearTimeout(timer);
            timer = setTimeout(() => fn(...args), delay);
        };
    }

    // Briefly change a button's label (used for "Link copied!").
    function flashLabel(button, message) {
        const original = button.textContent;
        button.textContent = message;
        setTimeout(() => { button.textContent = original; }, 2000);
    }


    /* ======================================================================
       2. Site-wide enhancements
       ====================================================================== */

    // Mark the current page in the navigation (helps users and screen readers).
    function markCurrentNav() {
        const normalise = path => (path.split('/').pop() || 'index').replace(/\.html$/, '') || 'index';
        const current = normalise(window.location.pathname);
        $$('nav a').forEach(link => {
            if (normalise(link.getAttribute('href')) === current) {
                link.setAttribute('aria-current', 'page');
            }
        });
    }

    // Fade sections in as they scroll into view (CSS handles the transition).
    // Only elements below the fold are animated so nothing flickers on load.
    // Technique: IntersectionObserver, see MDN (2026).
    function initScrollReveal() {
        if (prefersReducedMotion || !('IntersectionObserver' in window)) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08 });

        $$('main > section, .service-grid').forEach(target => {
            if (target.getBoundingClientRect().top > window.innerHeight) {
                target.classList.add('reveal');
                observer.observe(target);
            }
        });
    }

    // "Share this page": native share sheet where available, otherwise copy the link.
    // Supports the social-media side of the SEO plan.
    function initShare() {
        $$('[data-share]').forEach(button => {
            button.addEventListener('click', async () => {
                const shareData = {
                    title: document.title,
                    text: 'Sparkline Electrical Services – electricians in Cape Town',
                    url: window.location.href
                };
                try {
                    if (navigator.share) {
                        await navigator.share(shareData);
                    } else if (navigator.clipboard) {
                        await navigator.clipboard.writeText(shareData.url);
                        flashLabel(button, 'Link copied!');
                    } else {
                        flashLabel(button, 'Copy the address bar link');
                    }
                } catch (error) {
                    if (error.name !== 'AbortError') flashLabel(button, 'Could not share');
                }
            });
        });
    }


    /* ======================================================================
       3. Count-up animation (About page)
       ====================================================================== */

    function animateCount(node) {
        const target = Number(node.dataset.count);
        const suffix = node.dataset.suffix || '';
        const duration = 1200;
        const start = performance.now();

        function frame(now) {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3); // ease-out
            node.textContent = Math.round(target * eased) + suffix;
            if (progress < 1) requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    function initCountUp() {
        const counters = $$('[data-count]');
        if (!counters.length || prefersReducedMotion || !('IntersectionObserver' in window)) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCount(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.6 });

        counters.forEach(counter => {
            counter.textContent = '0' + (counter.dataset.suffix || '');
            observer.observe(counter);
        });
    }


    /* ======================================================================
       4. FAQ accordion (Services page)
       ====================================================================== */

    function setAccordionState(button, open) {
        button.setAttribute('aria-expanded', String(open));
        const panel = document.getElementById(button.getAttribute('aria-controls'));
        if (panel) panel.classList.toggle('is-open', open);
    }

    function initAccordion() {
        const triggers = $$('.accordion-trigger');
        triggers.forEach(trigger => {
            trigger.addEventListener('click', () => {
                const wasOpen = trigger.getAttribute('aria-expanded') === 'true';
                triggers.forEach(other => setAccordionState(other, false)); // one open at a time
                setAccordionState(trigger, !wasOpen);
            });
        });
    }


    /* ======================================================================
       5. Recent projects: dynamic content, search, filter and sort
       ====================================================================== */

    function sortProjects(list, mode) {
        const sorted = [...list];
        if (mode === 'az') sorted.sort((a, b) => a.title.localeCompare(b.title));
        else if (mode === 'za') sorted.sort((a, b) => b.title.localeCompare(a.title));
        else sorted.sort((a, b) => b.date.localeCompare(a.date)); // most recent first
        return sorted;
    }

    function buildProjectCard(project) {
        const image = el('img', {
            src: `images/project-${project.image}-480.jpg`,
            alt: project.alt,
            width: 480,
            height: 360,
            loading: 'lazy'
        });
        const thumb = el('button', {
            type: 'button',
            class: 'project-thumb',
            'aria-label': `View larger photo: ${project.title}`
        }, [image]);

        const caption = el('figcaption', {}, [
            el('h3', { text: project.title }),
            el('span', { class: 'project-tag', text: project.categoryLabel }),
            el('p', { text: project.description })
        ]);

        const card = el('figure', { class: 'project', dataset: { category: project.category } }, [thumb, caption]);
        return { project, node: card, thumb };
    }

    function initProjects() {
        const grid = $('#project-grid');
        if (!grid) return;

        const searchInput = $('#project-search');
        const sortSelect = $('#project-sort');
        const countEl = $('#project-count');
        const filterButtons = $$('.filter-button[data-filter]');

        const state = { query: '', category: 'all', sort: 'default' };
        let visibleProjects = [];

        const lightbox = createLightbox();
        const cards = PROJECTS.map(buildProjectCard);
        const cardById = new Map(cards.map(card => [card.project.id, card]));

        cards.forEach(card => {
            grid.append(card.node);
            card.thumb.addEventListener('click', () => {
                lightbox.open(visibleProjects, visibleProjects.indexOf(card.project), card.thumb);
            });
        });

        function applyFilters() {
            const query = state.query.trim().toLowerCase();

            const matches = PROJECTS.filter(project => {
                const inCategory = state.category === 'all' || project.category === state.category;
                const haystack = `${project.title} ${project.description} ${project.categoryLabel}`.toLowerCase();
                return inCategory && (!query || haystack.includes(query));
            });

            visibleProjects = sortProjects(matches, state.sort);
            const visibleIds = new Set(visibleProjects.map(p => p.id));

            // Re-order the matching cards, then hide the rest.
            visibleProjects.forEach(project => grid.append(cardById.get(project.id).node));
            cards.forEach(card => { card.node.hidden = !visibleIds.has(card.project.id); });

            countEl.textContent = visibleProjects.length === 0
                ? 'No projects match your search. Try a different keyword or filter.'
                : `Showing ${visibleProjects.length} of ${PROJECTS.length} projects`;
        }

        searchInput.addEventListener('input', debounce(() => {
            state.query = searchInput.value;
            applyFilters();
        }, 150));

        sortSelect.addEventListener('change', () => {
            state.sort = sortSelect.value;
            applyFilters();
        });

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                state.category = button.dataset.filter;
                filterButtons.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
                applyFilters();
            });
        });

        applyFilters();
    }


    /* ======================================================================
       6. Lightbox gallery
       ====================================================================== */

    function createLightbox() {
        let items = [];
        let index = 0;
        let opener = null;

        const image = el('img', { class: 'lightbox-image', alt: '' });
        const caption = el('p', { class: 'lightbox-caption' });
        const closeButton = el('button', { type: 'button', class: 'lightbox-close', 'aria-label': 'Close photo viewer', text: '×' });
        const prevButton = el('button', { type: 'button', class: 'lightbox-nav lightbox-prev', 'aria-label': 'Previous photo', text: '‹' });
        const nextButton = el('button', { type: 'button', class: 'lightbox-nav lightbox-next', 'aria-label': 'Next photo', text: '›' });
        const figure = el('figure', { class: 'lightbox-figure' }, [image, caption]);

        const overlay = el('div', {
            class: 'lightbox',
            role: 'dialog',
            'aria-modal': 'true',
            'aria-label': 'Project photo viewer',
            hidden: true
        }, [closeButton, prevButton, figure, nextButton]);
        document.body.append(overlay);

        function show(newIndex) {
            index = (newIndex + items.length) % items.length;
            const project = items[index];
            image.src = `images/project-${project.image}-1200.jpg`;
            image.alt = project.alt;
            caption.textContent = `${project.title} – ${project.categoryLabel} (${index + 1} of ${items.length})`;
        }

        function open(list, startIndex, openerElement) {
            if (!list.length) return;
            items = list;
            opener = openerElement;
            const single = items.length < 2;
            prevButton.hidden = single;
            nextButton.hidden = single;
            show(startIndex);
            overlay.hidden = false;
            document.body.classList.add('lightbox-open');
            requestAnimationFrame(() => overlay.classList.add('is-open')); // triggers the fade-in
            closeButton.focus();
        }

        function close() {
            overlay.classList.remove('is-open');
            overlay.hidden = true;
            document.body.classList.remove('lightbox-open');
            if (opener) opener.focus(); // return focus to where the user was
        }

        closeButton.addEventListener('click', close);
        prevButton.addEventListener('click', () => show(index - 1));
        nextButton.addEventListener('click', () => show(index + 1));
        overlay.addEventListener('click', event => { if (event.target === overlay) close(); });

        overlay.addEventListener('keydown', event => {
            if (event.key === 'Escape') close();
            else if (event.key === 'ArrowLeft' && items.length > 1) show(index - 1);
            else if (event.key === 'ArrowRight' && items.length > 1) show(index + 1);
            else if (event.key === 'Tab') {
                // Keep keyboard focus inside the dialog while it is open.
                const focusable = [closeButton, prevButton, nextButton].filter(b => !b.hidden);
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
            }
        });

        return { open, close };
    }


    /* ======================================================================
       7. Form validation engine
       ====================================================================== */

    // Each validator returns an error message, or '' when the value is valid.
    const validate = {
        name(value) {
            const v = value.trim();
            if (!v) return 'Please enter your full name.';
            if (v.length < 2) return 'Your name must be at least 2 characters long.';
            if (v.length > 60) return 'Your name must be 60 characters or fewer.';
            if (!/^[\p{L}][\p{L} '.\-]*$/u.test(v)) return 'Names can only contain letters, spaces, apostrophes, hyphens and full stops.';
            return '';
        },

        email(value) {
            const v = value.trim();
            if (!v) return 'Please enter your email address.';
            if (v.length > 100) return 'Your email address must be 100 characters or fewer.';
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return 'Enter a valid email address, for example name@example.com.';
            return '';
        },

        // South African numbers: 0 followed by 9 digits, or +27 followed by 9 digits.
        phone(value) {
            const digits = value.replace(/[\s\-()]/g, '');
            if (!digits) return 'Please enter your phone number.';
            if (!/^(\+27|0)\d{9}$/.test(digits)) return 'Enter a valid South African number, for example 021 555 0134 or +27 82 123 4567.';
            return '';
        },

        required(label) {
            return value => (value.trim() ? '' : `Please choose ${label}.`);
        },

        text(label, min, max) {
            return value => {
                const v = value.trim();
                if (!v) return `Please enter ${label}.`;
                if (v.length < min) return `Please enter at least ${min} characters.`;
                if (v.length > max) return `Please keep this to ${max} characters or fewer.`;
                return '';
            };
        },

        date(value) {
            if (!value) return 'Please choose a preferred date.';
            const chosen = new Date(value + 'T00:00:00');
            if (Number.isNaN(chosen.getTime())) return 'Enter a valid date.';
            const today = startOfToday();
            const limit = new Date(today);
            limit.setFullYear(limit.getFullYear() + 1);
            if (chosen < today) return 'The date cannot be in the past.';
            if (chosen > limit) return 'Please choose a date within the next 12 months.';
            return '';
        },

        optionalText(max) {
            return value => (value.length > max ? `Please keep this to ${max} characters or fewer.` : '');
        }
    };

    function showFieldError(input, message) {
        const errorEl = document.getElementById(`${input.id}-error`);
        if (errorEl) errorEl.textContent = message;
        if (message) input.setAttribute('aria-invalid', 'true');
        else input.removeAttribute('aria-invalid');
    }

    function bindCounter(textarea, counterEl, max) {
        const update = () => {
            const length = textarea.value.length;
            counterEl.textContent = `${length} / ${max} characters`;
            counterEl.classList.toggle('is-near-limit', length > max * 0.9);
        };
        textarea.addEventListener('input', update);
        update();
        return update;
    }

    /**
     * Wire up validation for a form.
     * rules: { fieldId: validatorFunction }
     * onValid: called with the form's FormData when every field passes.
     */
    function setupForm(form, rules, onValid) {
        const ids = Object.keys(rules);

        function checkField(id) {
            const input = document.getElementById(id);
            const message = rules[id](input.value);
            showFieldError(input, message);
            return !message;
        }

        ids.forEach(id => {
            const input = document.getElementById(id);
            input.addEventListener('blur', () => checkField(id));
            // Once a field has shown an error, re-check it live so the message clears as soon as it is fixed.
            const live = () => { if (input.getAttribute('aria-invalid') === 'true') checkField(id); };
            input.addEventListener('input', live);
            input.addEventListener('change', live);
        });

        form.addEventListener('submit', event => {
            event.preventDefault();

            // Honeypot: real visitors never fill this hidden field, bots usually do.
            const honeypot = form.elements['bot-field'];
            if (honeypot && honeypot.value) return;

            let firstInvalid = null;
            ids.forEach(id => {
                if (!checkField(id) && !firstInvalid) firstInvalid = document.getElementById(id);
            });
            if (firstInvalid) {
                firstInvalid.focus();
                return;
            }
            onValid(new FormData(form));
        });
    }

    function setBusy(button, busy, busyLabel) {
        if (busy) {
            button.dataset.label = button.textContent;
            button.textContent = busyLabel;
            button.disabled = true;
            button.setAttribute('aria-busy', 'true');
        } else {
            button.textContent = button.dataset.label || button.textContent;
            button.disabled = false;
            button.removeAttribute('aria-busy');
        }
    }


    /* ======================================================================
       8. Enquiry form
       ====================================================================== */

    // AJAX submission. In demo mode this only waits briefly; set SIMULATE_SERVER
    // to false to POST the data with fetch() instead.
    function sendToServer(formData) {
        if (SIMULATE_SERVER) {
            return new Promise(resolve => setTimeout(resolve, 900));
        }
        return fetch(FORM_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(formData).toString()
        }).then(response => {
            if (!response.ok) throw new Error(`Server responded with ${response.status}`);
        });
    }

    function describeAvailability(dateValue) {
        const date = new Date(dateValue + 'T00:00:00');
        const daysAway = Math.round((date - startOfToday()) / 86400000);
        const weekday = date.getDay(); // 0 = Sunday, 6 = Saturday
        const longDate = date.toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

        if (weekday === 0) {
            return `${longDate} is a Sunday. We only take emergency work on Sundays, so we will phone you to arrange the nearest weekday slot.`;
        }
        if (weekday === 6) {
            return `${longDate} is a Saturday. Saturday slots are available by arrangement with a 25% weekend surcharge on labour.`;
        }
        if (daysAway <= 1) {
            return 'Same-day and next-day slots are limited. We will phone you within two hours (during business hours) to confirm whether we can attend.';
        }
        return `We have capacity on ${longDate}. A team member will confirm your arrival window within one business day.`;
    }

    function buildEnquiryResponse(values) {
        const job = PRICING[values['job-type']] || PRICING.other;
        const firstName = values['full-name'].trim().split(/\s+/)[0];
        const prettyDate = new Date(values['preferred-date'] + 'T00:00:00')
            .toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' });

        const summary = el('dl', { class: 'response-list' }, [
            el('dt', { text: 'Job type' }), el('dd', { text: job.label }),
            el('dt', { text: 'Area' }), el('dd', { text: values.location.trim() }),
            el('dt', { text: 'Preferred date' }), el('dd', { text: prettyDate }),
            el('dt', { text: 'Cost guide' }), el('dd', { text: job.estimate }),
            el('dt', { text: 'Availability' }), el('dd', { text: describeAvailability(values['preferred-date']) })
        ]);

        const again = el('button', { type: 'button', class: 'cta-button', text: 'Make another enquiry' });
        again.addEventListener('click', () => {
            const panel = $('#enquiry-response');
            panel.hidden = true;
            panel.replaceChildren();
            $('#full-name').focus();
        });

        return [
            el('h3', { text: `Thanks, ${firstName}!` }),
            el('p', { text: 'We have received your enquiry. Here is what to expect:' }),
            summary,
            el('p', { class: 'response-note', text: `${job.note} This is an estimate, not a final quote. We will confirm everything by email or phone within one business day.` }),
            again
        ];
    }

    function initEnquiryForm() {
        const form = $('#enquiry-form');
        if (!form) return;

        // Only allow dates from today to one year ahead.
        const dateInput = $('#preferred-date');
        const today = startOfToday();
        const limit = new Date(today);
        limit.setFullYear(limit.getFullYear() + 1);
        const toISO = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        dateInput.min = toISO(today);
        dateInput.max = toISO(limit);

        const updateCounter = bindCounter($('#message'), $('#message-count'), 500);
        const panel = $('#enquiry-response');

        setupForm(form, {
            'full-name': validate.name,
            'email': validate.email,
            'phone': validate.phone,
            'job-type': validate.required('a type of job'),
            'location': validate.text('your suburb or area', 2, 60),
            'preferred-date': validate.date,
            'message': validate.optionalText(500)
        }, async formData => {
            const button = $('button[type="submit"]', form);
            setBusy(button, true, 'Working out your quote…');
            panel.hidden = true;

            try {
                await sendToServer(formData);
                const values = Object.fromEntries(formData);
                panel.classList.remove('is-error');
                panel.replaceChildren(...buildEnquiryResponse(values));
                form.reset();
                updateCounter();
            } catch (error) {
                panel.classList.add('is-error');
                panel.replaceChildren(
                    el('h3', { text: 'Something went wrong' }),
                    el('p', { text: 'Sorry, we could not send your enquiry. Your details are still in the form. Please try again, or phone us on 021 555 0134.' })
                );
            } finally {
                setBusy(button, false);
                panel.hidden = false;
                panel.focus();
                panel.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'center' });
            }
        });
    }


    /* ======================================================================
       9. Contact form: compile the message into an email
       ====================================================================== */

    function showEmailPreview(values) {
        const name = values['c-name'].trim();
        const subject = `${values['c-type']} – website message from ${name}`;
        const body = [
            `Name: ${name}`,
            `Email: ${values['c-email'].trim()}`,
            `Type of message: ${values['c-type']}`,
            '',
            'Message:',
            values['c-message'].trim(),
            '',
            '– Sent from the Sparkline Electrical Services website contact form'
        ].join('\r\n');

        const mailto = `mailto:${RECIPIENT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

        const panel = $('#email-preview');
        const openLink = el('a', { class: 'cta-button', href: mailto, text: 'Open in my email app' });
        const editButton = el('button', { type: 'button', class: 'secondary-button', text: 'Edit message' });
        editButton.addEventListener('click', () => {
            panel.hidden = true;
            $('#c-message').focus();
        });

        panel.replaceChildren(
            el('h3', { text: 'Your email is ready' }),
            el('p', { text: 'Check the details below. When you press the button, your email app opens with this message ready to send.' }),
            el('dl', { class: 'response-list' }, [
                el('dt', { text: 'To' }), el('dd', { text: RECIPIENT_EMAIL }),
                el('dt', { text: 'Subject' }), el('dd', { text: subject })
            ]),
            el('pre', { class: 'email-body', text: body }),
            el('div', { class: 'response-actions' }, [openLink, editButton])
        );
        panel.hidden = false;
        panel.focus();
        panel.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'center' });
    }

    function initContactForm() {
        const form = $('#contact-form-element');
        if (!form) return;

        bindCounter($('#c-message'), $('#c-message-count'), 1000);

        setupForm(form, {
            'c-name': validate.name,
            'c-email': validate.email,
            'c-type': validate.required('a type of message'),
            'c-message': validate.text('your message', 10, 1000)
        }, formData => showEmailPreview(Object.fromEntries(formData)));
    }


    /* ======================================================================
       10. Interactive Leaflet map (Contact page)
       Follows the Leaflet Quick Start Guide (Leaflet, 2026).
       ====================================================================== */

    // Straight-line distance between two coordinates, in kilometres (haversine formula).
    function distanceKm(lat1, lng1, lat2, lng2) {
        const toRad = deg => (deg * Math.PI) / 180;
        const earthRadius = 6371;
        const dLat = toRad(lat2 - lat1);
        const dLng = toRad(lng2 - lng1);
        const a = Math.sin(dLat / 2) ** 2 +
                  Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
        return 2 * earthRadius * Math.asin(Math.sqrt(a));
    }

    function buildPopup(location) {
        return el('div', { class: 'map-popup' }, [
            el('strong', { text: location.name }),
            el('br'),
            document.createTextNode(location.address),
            el('br'),
            el('a', { href: `tel:${location.tel}`, text: location.phone }),
            el('br'),
            el('a', {
                href: `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`,
                target: '_blank',
                rel: 'noopener noreferrer',
                text: 'Get directions'
            })
        ]);
    }

    function initMap() {
        const canvas = $('#map-canvas');
        if (!canvas) return;
        const status = $('#map-status');

        // Leaflet is loaded from a CDN; explain clearly if it is unavailable.
        if (typeof L === 'undefined') {
            // Hide the empty map and its dead buttons, and offer direct links instead.
            canvas.hidden = true;
            const controls = $('.map-controls');
            if (controls) controls.hidden = true;
            status.textContent = 'The interactive map could not be loaded. Use these links to get directions instead:';
            status.append(el('ul', { class: 'map-fallback-links' }, LOCATIONS.map(location =>
                el('li', {}, [el('a', {
                    href: `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`,
                    target: '_blank',
                    rel: 'noopener noreferrer',
                    text: `Directions to ${location.name}`
                })])
            )));
            return;
        }

        const map = L.map(canvas, { scrollWheelZoom: false }).setView([-33.94, 18.55], 11);

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Scrolling the page should not zoom the map by accident; enable wheel zoom after a click.
        map.on('click', () => map.scrollWheelZoom.enable());
        map.on('mouseout', () => map.scrollWheelZoom.disable());

        const pinIcon = L.divIcon({
            className: 'map-pin',
            html: '<span></span>',
            iconSize: [28, 28],
            iconAnchor: [14, 28],
            popupAnchor: [0, -26]
        });

        const markers = {};
        LOCATIONS.forEach(location => {
            markers[location.id] = L.marker([location.lat, location.lng], {
                icon: pinIcon,
                title: location.name,
                alt: location.name
            }).addTo(map).bindPopup(buildPopup(location));
        });

        const bounds = L.latLngBounds(LOCATIONS.map(l => [l.lat, l.lng]));
        map.fitBounds(bounds, { padding: [50, 50] });

        // Buttons that move the map to a location.
        const targetButtons = $$('[data-map-target]');
        targetButtons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mapTarget === 'both')));

        targetButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.dataset.mapTarget;
                targetButtons.forEach(b => b.setAttribute('aria-pressed', String(b === button)));

                if (target === 'both') {
                    map.fitBounds(bounds, { padding: [50, 50], animate: !prefersReducedMotion });
                    status.textContent = 'Showing both locations.';
                } else {
                    const location = LOCATIONS.find(l => l.id === target);
                    map.setView([location.lat, location.lng], 15, { animate: !prefersReducedMotion });
                    markers[target].openPopup();
                    status.textContent = `Showing ${location.name}.`;
                }
            });
        });

        // "Find my nearest branch" uses the browser Geolocation API (MDN, 2026).
        let youMarker = null;
        $('#locate-me').addEventListener('click', () => {
            if (!('geolocation' in navigator)) {
                status.textContent = 'Your browser does not support location lookup. Please choose a branch above.';
                return;
            }
            status.textContent = 'Finding your location…';

            navigator.geolocation.getCurrentPosition(position => {
                const { latitude, longitude } = position.coords;
                const ranked = LOCATIONS
                    .map(location => ({ location, km: distanceKm(latitude, longitude, location.lat, location.lng) }))
                    .sort((a, b) => a.km - b.km);
                const nearest = ranked[0];

                if (youMarker) youMarker.remove();
                youMarker = L.circleMarker([latitude, longitude], {
                    radius: 8, color: '#16283F', weight: 3, fillColor: '#F2A20C', fillOpacity: 1
                }).addTo(map).bindTooltip('You are here');

                map.fitBounds(L.latLngBounds([[latitude, longitude], [nearest.location.lat, nearest.location.lng]]),
                    { padding: [60, 60], animate: !prefersReducedMotion });
                markers[nearest.location.id].openPopup();
                targetButtons.forEach(b => b.setAttribute('aria-pressed', 'false'));
                status.textContent = `Your nearest branch is ${nearest.location.name}, about ${nearest.km.toFixed(1)} km away in a straight line.`;
            }, error => {
                const messages = {
                    1: 'Location access was blocked. You can still choose a branch with the buttons above.',
                    2: 'We could not work out your location. Please choose a branch with the buttons above.',
                    3: 'Finding your location took too long. Please try again or choose a branch above.'
                };
                status.textContent = messages[error.code] || messages[2];
            }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 });
        });
    }


    /* ======================================================================
       11. Start-up
       ====================================================================== */

    function init() {
        document.documentElement.classList.add('js'); // lets CSS style JS-only features safely
        markCurrentNav();
        initScrollReveal();
        initShare();
        initCountUp();
        initAccordion();
        initProjects();
        initEnquiryForm();
        initContactForm();
        initMap();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();